# Mi Página en GitHub Pages

Este repositorio contiene una página web simple publicada con **GitHub Pages**.

## ¿Qué contiene?

- `index.html`: Página web principal.
- `README.md`: Esta descripción.

## Enlace en línea

Cuando actives GitHub Pages, verás aquí tu página activa. 🚀
